"""
Core module for LyzrBoost providing agent API wrappers and workflow management.
""" 