"""
LyzrBoost - A Python package to simplify orchestration and debugging of Lyzr AI agents.
"""

__version__ = "0.1.0"
__author__ = "Lyzr AI" 