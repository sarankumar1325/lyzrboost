"""
Command line interface module for LyzrBoost.
""" 